import * as React from 'react';
import {View} from 'react-native';
import{ createAppContainer, createSwitchNavigator } from 'react-navigation';

import HomeScreen from './Screens/HomeScreen';
import JokeScreen from './Screens/JokeScreen';
import HoroscopeScreen from './Screens/HoroscopeScreen';
import NewsScreen from './Screens/NewsScreen';
import WeatherScreen from './Screens/WeatherScreen';

export default class App extends React.Component{
  render(){
    return(
      <View>
      <AppContainer />
      </View>
    );
  }
}
var AppNavigator = createSwitchNavigator({
   HomeScreen : HomeScreen,
   JokeScreen : JokeScreen,
   NewsScreen : NewsScreen,
   HoroscopeScreen : HoroscopeScreen,
   WeatherScreen : WeatherScreen,
});

const AppContainer = createAppContainer(AppNavigator);
