import React, { Component } from 'react';
import {Text ,View ,TouchableOpacity ,StyleSheet } from 'react-native';

export default class HomeScreen extends React.Component{
  render(){
    return(
      <View style={styles.buttonContainer}>
      <TouchableOpacity
      style={styles.button}
      onPress={()=>this.props.navigation.navigate('JokeScreen')}>
      <Text>Reader Joke</Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.button}
      onPress={()=>this.props.navigation.navigate('NewsScreen')}>
      <Text>News</Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.button}
      onPress={()=>this.props.navigation.navigate('WeatherScreen')}>
      <Text>Weather</Text>
      </TouchableOpacity>

      <TouchableOpacity
      style={styles.button}
      onPress={()=>this.props.navigation.navigate('HoroscopeScreen')}>
      <Text>Horoscope</Text>
      </TouchableOpacity>

      </View>

      
    );
  }
}

const styles = StyleSheet.create({
  button: {
    marginTop: 50,
    borderWidth: 2,
    justifyContent: 'center',
    alignSelf:'center',
    alignItems:'center',
    width: 200,
    height: 50,
    borderRadius: 15,
    backgroundColor:'#aa78ff'
  },
})