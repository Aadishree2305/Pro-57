import React, { Component } from 'react';
import {Text ,View ,TouchableOpacity ,StyleSheet } from 'react-native';

export default class JokeScreen extends React.Component{
  render(){
    return(
      <View>
      <Text style={styles.jokeContainer}> Why is a koala not a bear,Beacuse its not koalifyed</Text></View>
    );
  }
}

const styles = StyleSheet.create({
  jokeContainer:{
    fontStyle:'bold',
    fontSize:'70',
  }
});

