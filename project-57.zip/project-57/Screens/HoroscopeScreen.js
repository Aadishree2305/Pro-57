import React, { Component } from 'react';
import {Text ,View ,TouchableOpacity ,StyleSheet } from 'react-native';

export default class HoroscopeScreen extends React.Component{
  render(){
    return(
      <View>
      <Text style={styles.jokeContainer}>Wearing yellow is good ,today</Text></View>
    );
  }
}

const styles = StyleSheet.create({
  jokeContainer:{
    fontStyle:'bold',
    fontSize:'70',
  }
});

