import React, { Component } from 'react';
import {Text ,View ,TouchableOpacity ,StyleSheet } from 'react-native';

export default class WeatherScreen extends React.Component{
  render(){
    return(
      <View>
      <Text style={styles.wContainerText}>Today's temperature: 39C </Text>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  wContainerText:{
    fontStyle:'bold',
    fontSize:'70',
  }
});

