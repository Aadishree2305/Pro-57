import React, { Component } from 'react';
import {Text ,View ,TouchableOpacity ,StyleSheet } from 'react-native';

export default class NewsScreen extends React.Component{
  render(){
    return(
      <View>
      <Text style={styles.newsContainer}> Corona virus mutated in summers</Text></View>
    );
  }
}

const styles = StyleSheet.create({
  newsContainer:{
    fontStyle:'bold',
    fontSize:'70',
  }
});

